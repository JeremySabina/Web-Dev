# Final Project

>## Favorite thing as a child: *Video Games*

## Pages

1. Overview - History of Video Games, Fun Facts, The Positive Effects
    1. Navbar Component
    2. Image Component
    3. List Component
2. Competitive - Top Competitive Games, Esports, Facts and Stats
    1. Navbar Component
    2. Image Component
    3. List Component
3. Top Games - List your Top Games, Compare to Others
    1. Navbar Component
    2. Form Component
    3. Button Component
4. Newsletter - Subscribe, Thank You Message
    1. Navbar Component
    2. Form Component
    3. Button Component

## Componenets

1. Image Component - Choose which image through props to set on each page.
2. List Component - Lists out data from a given api that is fed into the component as a prop.
3. Contact Form Component - Lets a user fill out a form with their name, email, and games they are interested in.
4. Favorite Game Form Component - Lets a user fill out a form with their favorite games and add to the list.
5. Button Component - A button to submit on the form component.
6. Navbar Component - Navigation bar for all webpages.